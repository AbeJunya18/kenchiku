package com.seproject.buildmanager.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "mst_constoruction")
@Data
@NoArgsConstructor
// @NamedEntityGraph(name = "MstConstruction.withAllAssociations", includeAllAttributes = true)
public class MstConstruction {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(name = "cost_group_name", nullable = false)
  private String cost_group_name;

  @Column(name = "status", nullable = false)
  private Integer status;

  @Column(name = "regist_date", nullable = false)
  private String regist_date;

  @Column(name = "update_date")
  private String update_date;

  @Column(name = "update_user_id", nullable = false)
  private int update_user_id;

}
