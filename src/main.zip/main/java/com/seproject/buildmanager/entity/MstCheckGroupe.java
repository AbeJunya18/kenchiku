package com.seproject.buildmanager.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "checkgroup_registration")
@Data
@NoArgsConstructor

public class MstCheckGroupe {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private int id; // ID

  @Column(name = "CHECK_GROUP_NAME")
  private String check_groupe_name; // グループ名称

  @Column(name = "status")
  private int status; // ステータス

  @Column(name = "REGIST_DATE")
  private LocalDateTime regist_date; // 登録日

  @Column(name = "UPDATE_DATE")
  private LocalDateTime update_date; // 最終更新日

  @Column(name = "UPDATE_USER_ID")
  private int update_user_id; // 最終更新者



}
