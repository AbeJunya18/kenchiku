package com.seproject.buildmanager.entity;

import java.time.LocalDateTime;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Table(name = "mst_customer")
@Data
@NoArgsConstructor
public class MstCustomer {

  @Id
  @GeneratedValue(strategy = GenerationType.IDENTITY)
  private Integer id;

  @Column(name = "cust_kind")
  private int custKind;

  @Column(name = "cust_corp_name")
  private String corpName;

  @Column(name = "cust_corp_name_kana")
  private String corpKana;

  @Column(name = "cust_department_name")
  private String department;

  @Column(name = "cust_l_name")
  private String lName;

  @Column(name = "cust_f_name")
  private String fName;

  @Column(name = "cust_l_name_kana")
  private String lNameKana;

  @Column(name = "cust_f_name_kana")
  private String fNameKana;

  @Column(name = "cust_zip")
  private String zip;
  

  @Column(name = "cust_prefecture")
  private int prefecture;

  @Column(name = "cust_address1")
  private String address1;

  @Column(name = "cust_address2")
  private String address2;

  @Column(name = "cust_tel")
  private String tel;

  @Column(name = "cust_mobile")
  private String mobile;

  @Column(name = "cust_mail")
  private String mail;

  @Column(name = "status")
  private Integer status;

  @Column(name = "regist_date")
  private LocalDateTime registDate;

  @Column(name = "update_date")
  private LocalDateTime updateDate;

  @Column(name = "updated_user_id")
  private Integer updatedUserId;

}
