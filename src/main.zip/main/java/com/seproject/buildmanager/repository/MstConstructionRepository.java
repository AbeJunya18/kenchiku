package com.seproject.buildmanager.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.seproject.buildmanager.entity.MstConstruction;

public interface MstConstructionRepository extends JpaRepository<MstConstruction, Integer> {
  @Query("UPDATE MstConstruction u SET u.status = CASE WHEN u.status = 1 THEN 0 ELSE 1 END WHERE u.id = :name")
  void toggleStatus(@Param("name") String name);

}
