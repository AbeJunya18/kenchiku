package com.seproject.buildmanager.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.transaction.annotation.Transactional;
import com.seproject.buildmanager.entity.MstCustomer;

public interface MstCustomerRepository extends JpaRepository<MstCustomer, Integer> {

  // @EntityGraph(value = "MstCustomer.withAllAssociations", type =
  // EntityGraph.EntityGraphType.FETCH)
  @EntityGraph(value = "MstUser.withAllAssociations", type = EntityGraph.EntityGraphType.FETCH)
  public List<MstCustomer> findAll();

  @Query(
      value = "SELECT c.id AS id, c.cust_l_name, c.cust_f_name, c.cust_l_name_kana, c.cust_f_name_kana, c.cust_corp_name, c.cust_corp_name_kana, c.cust_zip, c.cust_address1, c.cust_address2, c.mail, c.cust_tel, c.cust_mobile, c.status, c.created_at, c.updated_at "
          + "FROM mst_customer c ",
      // + "LEFT JOIN mst_auth a ON u.mst_auth_id = a.id "
      // + "WHERE u.login_cd = :loginCd "
      // + "GROUP BY u.id, u.login_cd, u.password, u.l_name, u.f_name, u.l_name_kana, u.f_name_kana,
      // u.tel, u.email, u.status, u.created_at, u.updated_at, u.updated_mst_user_id",
      nativeQuery = true)
  Optional<MstCustomer> findByLoginCd(@Param("loginCd") String loginCd);

  @Modifying
  @Transactional
  @Query("UPDATE MstCustomer c SET c.status = CASE WHEN c.status = 1 THEN 0 ELSE 1 END WHERE c.id = :custId")
  void toggleStatus(@Param("custId") Integer custId);


}
