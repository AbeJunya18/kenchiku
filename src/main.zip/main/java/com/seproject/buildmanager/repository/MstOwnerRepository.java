package com.seproject.buildmanager.repository;

import java.util.List;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.seproject.buildmanager.entity.MstOwner;

public interface MstOwnerRepository extends JpaRepository<MstOwner, Integer> {

  // @EntityGraph(value = "MstOwner.withAllAssociations", type = EntityGraph.EntityGraphType.FETCH)
  @EntityGraph(value = "MstUser.withAllAssociations", type = EntityGraph.EntityGraphType.FETCH)
  public List<MstOwner> findAll();


  @Query("UPDATE MstOwner SET status = CASE WHEN status = 1 THEN 0 ELSE 1 END WHERE id=:id")
  void toggleStatus(@Param("id") Integer ownerId);
}
