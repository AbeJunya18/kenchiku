package com.seproject.buildmanager.repository;

import java.util.List;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import com.seproject.buildmanager.entity.MstCheckGroupe;


@Repository
public interface MstCheckGroupeRepositry extends JpaRepository<MstCheckGroupe, Integer> {
  @EntityGraph(value = "MstUser.withAllAssociations", type = EntityGraph.EntityGraphType.FETCH)
  // @EntityGraph(value = "MstCheckGroupe.withAllAssociations",type =
  // EntityGraph.EntityGraphType.FETCH)
  public List<MstCheckGroupe> findAll();

  // @Query(
  // value = "SELECT ID,CHECK_GROUP_NAME,STATUS,REGIST_DATE,UPDATE_DATE,UPDATE_USER_ID FROM
  // checkgroup_registration",
  // nativeQuery = true
  //
  // )
  @Query("UPDATE MstOwner SET status = CASE WHEN status = 1 THEN 0 ELSE 1 END WHERE id=:id")
  void toggleStatus(@Param("id") Integer groupeId);

  // List<MstCheckGroupe> findAllCheckGroups();



}
