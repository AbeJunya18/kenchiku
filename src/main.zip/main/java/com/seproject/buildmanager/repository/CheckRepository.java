// package com.seproject.buildmanager.repository;
//
// import java.util.List;
// import java.util.Optional;
// import org.springframework.data.jpa.repository.EntityGraph;
// import org.springframework.data.jpa.repository.Query;
// import org.springframework.data.repository.query.Param;
// import com.seproject.buildmanager.entity.MstCustomer;
// import com.seproject.buildmanager.entity.MstUser;
//
//// public interface CheckRepository {
////
////// @EntityGraph(value = "auth_with_all_associations", type = EntityGraph.EntityGraphType.FETCH)
////// public List<Check> findAll();
//////
////// @Query(
////// value = "SELECT mst_check.id AS id, mst_check.check_detail, mst_check.status,
// mst_check.regist_date, mst_check.update_date, mst_check.update_user_id "
////// + "mst_check.id AS id, mst_check.check_detail, mst_check.status, mst_check.regist_date,
// mst_check.update_date, mst_check.update_user_id ",
////// nativeQuery = true)
////// Optional<Check> findByLoginCd(@Param("loginCd") String loginCd);
//////
////// }
