package com.seproject.buildmanager.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.EntityGraph;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import com.seproject.buildmanager.entity.MstCode;

public interface MstCodeRepesitory extends JpaRepository<MstCode, Integer> {
  @EntityGraph(value = "MstUser.withAllAssociations", type = EntityGraph.EntityGraphType.FETCH)
  public List<MstCode> findAll();

  @Query(
      value = "SELECT id, code_kind, code_branch_num, code_name, status, created_at, updated_at, updated_mst_user_id FROM mst_code WHERE code_kind = :codeKind ",
      nativeQuery = true)
  public List<MstCode> findByCodeKind(@Param("codeKind") Integer codeKind);

  @Query(
      value = "SELECT id, code_kind, code_branch_num, code_name, status, created_at, updated_at, updated_mst_user_id "
          + "FROM mst_code " + "WHERE code_name = :codeName ",
      nativeQuery = true)
  public Optional<MstCode> findByCodeName(@Param("codeName") String codeName);
}
