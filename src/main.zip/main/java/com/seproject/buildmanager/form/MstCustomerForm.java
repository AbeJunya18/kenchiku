package com.seproject.buildmanager.form;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class MstCustomerForm {

  private Integer id;

  private int cust_kind;

  @Size(max = 25, message = "Last Name must be 25 characters or less")
  private String corpName;

  @Size(max = 25, message = "Last Name must be 25 characters or less")
  private String corpKana;

  @Size(max = 25, message = "Last Name must be 25 characters or less")
  private String department;

  @Size(max = 10, message = "Last Name must be 10 characters or less")
  private String lName;

  @Size(max = 10, message = "First Name must be 10 characters or less")
  private String fName;

  @Size(max = 10, message = "Last Name Kana must be 10 characters or less")
  private String lNameKana;

  @Size(max = 10, message = "First Name Kana must be 10 characters or less")
  private String fNameKana;

  @Size(max = 7, message = "First Name Kana must be 7 characters or less")
  private String zip;
  
  private String prefectures;// 都道府県

  @Size(max = 50, message = "First Name Kana must be 50 characters or less")
  private String address1;

  @Size(max = 25, message = "First Name Kana must be 25 characters or less")
  private String address2;

  @Size(max = 14, message = "Tel must be 14 characters or less")
  private String tel;

  @Size(max = 14, message = "Tel must be 14 characters or less")
  private String mobile;

  @Email(message = "Email should be valid")
  @Size(max = 100, message = "Email must be 100 characters or less")
  private String mail;

  private String status;

  private String transactionToken;

}
