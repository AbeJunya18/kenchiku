package com.seproject.buildmanager.form;

import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class MstOwnerForm {

  private String id;// id

  private String client;// 顧客名

  private String clientId;// 顧客id

  private String individual;// 個人・法人区分

  @Size(max = 25, message = "Corporation must be 25 characters or less")
  private String corporation;// 法人名

  @Size(max = 25, message = "CorporationKana must be 25 characters or less")
  private String corporationKana;// 法人名かな

  @Size(max = 25, message = "Department must be 25 characters or less")
  private String department;// 部署

  @Size(max = 10, message = "Last Name must be 10 characters or less")
  private String lName;// 姓

  @Size(max = 10, message = "First Name must be 10 characters or less")
  private String fName;// 名

  @Size(max = 10, message = "Last Name Kana must be 10 characters or less")
  private String lNameKana;// 姓かな

  @Size(max = 10, message = "First Name Kana must be 10 characters or less")
  private String fNameKana;// 名かな

  @Size(max = 7, message = "PostCode must be 10 characters or less")
  private String postCode;// 郵便番号

  private String prefectures;// 都道府県

  @Size(max = 50, message = "Address must be 10 characters or less")
  private String address;// 住所

  @Size(max = 25, message = "Building Name must be 25 characters or less")
  private String buildingName;// 建物名

  @Size(max = 13, message = "Phone must be 13 characters or less")
  private String phone;// 電話番号

  @Size(max = 13, message = "Mobile Phone must be 13 characters or less")
  private String mobilePhone;// 携帯番号

  @Email(message = "Email should be valid")
  @Size(max = 50, message = "Email must be 13 characters or less")
  private String email;// メールアドレス

  private String status;

  private String transactionToken;
}
