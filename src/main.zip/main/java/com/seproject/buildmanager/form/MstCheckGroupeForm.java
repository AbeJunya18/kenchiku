package com.seproject.buildmanager.form;

import lombok.Data;

@Data
public class MstCheckGroupeForm {

  /**
   * @NotBlank(message = "グループ名を入力してください")
   * @Size(max = 10, message = "最大１０文字まで入力できます") private String Groupe;
   **/
}
