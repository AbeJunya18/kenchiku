package com.seproject.buildmanager.form;

import jakarta.validation.constraints.Size;
import lombok.Data;

@Data
public class MstConstructionForm {
  private Integer id;

  @Size(max = 20, message = "cost_group_name must be 20 characters or less")
  private String cost_group_name;

  private Integer status;

  private String regist_date;

  private String update_date;

  private int update_user_id;

}
