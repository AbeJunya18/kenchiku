package com.seproject.buildmanager.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Service;
import com.seproject.buildmanager.entity.MstCode;
import com.seproject.buildmanager.repository.MstCodeRepesitory;

@Service
public class MstCodeService {

  private static final Logger logger = LoggerFactory.getLogger(SpringBootApplication.class);

  @Autowired
  private MstCodeRepesitory mstCodeRepesitory;

  public List<MstCode> getAllCode() {
    logger.info("--- MstCodeService.getAllCode START ---");

    List<MstCode> codes = mstCodeRepesitory.findAll();

    logger.info("--- MstCodeService.getAllCode END ---");

    return codes;
  }

  public List<MstCode> getCodeByKind(Integer codeKind) {
    return mstCodeRepesitory.findByCodeKind(codeKind);
  }

  public MstCode getCodeByName(String codeName) {
    return mstCodeRepesitory.findByCodeName(codeName).orElse(new MstCode());
  }

}
