package com.seproject.buildmanager.service;

import java.time.LocalDateTime;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Service;
import com.seproject.buildmanager.entity.MstCode;
import com.seproject.buildmanager.entity.MstOwner;
import com.seproject.buildmanager.form.MstOwnerForm;
import com.seproject.buildmanager.repository.MstCodeRepesitory;
import com.seproject.buildmanager.repository.MstOwnerRepository;

@Service
public class MstOwnerService {

  private static final Logger logger = LoggerFactory.getLogger(SpringBootApplication.class);

  @Autowired
  private MstOwnerRepository mstOwnerRepository;

  @Autowired
  private MstCodeRepesitory mstCodeRepesitory;

  public List<MstOwner> getAllOwner() {// 全権検索

    logger.info("--- MstOwnerService.getAllOwner START ---");

    List<MstOwner> owners = mstOwnerRepository.findAll();

    logger.info("--- MstUserService.getAllUsers END ---");

    return owners;

  }

  public MstOwnerForm registerOwnerForm() {// インスタンス生成

    logger.info("--- MstUserService.registerOwnerForm START ---");

    MstOwnerForm tmp = new MstOwnerForm();

    logger.info("--- MstUserService.registerOwnerForm END ---");

    return tmp;

  }

  public MstOwner saveOwnerRegister(MstOwnerForm mstOwnerForm) {// 登録

    logger.info("--- MstOwnerService.saveUser START ---");

    MstOwner tmp = new MstOwner();
    tmp.setClientId(Integer.parseInt(mstOwnerForm.getClientId()));
    tmp.setAddress(mstOwnerForm.getAddress());
    tmp.setBuildingName(mstOwnerForm.getBuildingName());
    tmp.setCorporation(mstOwnerForm.getCorporation());
    tmp.setCorporationKana(mstOwnerForm.getCorporationKana());
    tmp.setDepartment(mstOwnerForm.getDepartment());
    tmp.setEmail(mstOwnerForm.getEmail());
    tmp.setFName(mstOwnerForm.getFName());
    tmp.setFNameKana(mstOwnerForm.getFNameKana());

    tmp.setLName(mstOwnerForm.getLName());
    tmp.setLNameKana(mstOwnerForm.getLNameKana());
    tmp.setMobilePhone(mstOwnerForm.getMobilePhone());
    tmp.setPhone(mstOwnerForm.getPhone());
    tmp.setPostCode(mstOwnerForm.getPostCode());


    MstCode mstCode =
        mstCodeRepesitory.findByCodeName(mstOwnerForm.getIndividual()).orElse(new MstCode());
    tmp.setIndividual(mstCode.getCodeBranchNum());

    mstCode = mstCodeRepesitory.findByCodeName(mstOwnerForm.getPrefectures()).orElse(new MstCode());
    tmp.setPrefectures(mstCode.getCodeBranchNum());

    tmp.setUpdatedAt(null);


    try {
      tmp.setStatus(Integer.valueOf(mstOwnerForm.getStatus()));
    } catch (NumberFormatException e) {
      tmp.setStatus(1);
    }
    tmp.setCreatedAt(LocalDateTime.now());

    MstOwner result = mstOwnerRepository.save(tmp);

    logger.info("--- MstOwnerService.saveUser END ---");
    return result;

  }

  public MstOwner getOwnerId(int id) {// id検索

    return mstOwnerRepository.findById(id).orElse(new MstOwner());

  }

  public MstOwner saveOwnerUpdate(MstOwnerForm mstOwnerForm) {// 変更

    logger.info("--- MstOwnerService.saveUser START ---");

    MstOwner tmp = new MstOwner();
    tmp.setClientId(Integer.parseInt(mstOwnerForm.getClientId()));
    tmp.setAddress(mstOwnerForm.getAddress());
    tmp.setBuildingName(mstOwnerForm.getBuildingName());
    tmp.setCorporation(mstOwnerForm.getCorporation());
    tmp.setCorporationKana(mstOwnerForm.getCorporationKana());
    tmp.setDepartment(mstOwnerForm.getDepartment());
    tmp.setEmail(mstOwnerForm.getEmail());
    tmp.setFName(mstOwnerForm.getFName());
    tmp.setFNameKana(mstOwnerForm.getFNameKana());

    tmp.setLName(mstOwnerForm.getLName());
    tmp.setLNameKana(mstOwnerForm.getLNameKana());
    tmp.setMobilePhone(mstOwnerForm.getMobilePhone());
    tmp.setPhone(mstOwnerForm.getPhone());
    tmp.setPostCode(mstOwnerForm.getPostCode());


    MstCode mstCode =
        mstCodeRepesitory.findByCodeName(mstOwnerForm.getIndividual()).orElse(new MstCode());
    tmp.setIndividual(mstCode.getCodeBranchNum());

    mstCode = mstCodeRepesitory.findByCodeName(mstOwnerForm.getPrefectures()).orElse(new MstCode());
    tmp.setPrefectures(mstCode.getCodeBranchNum());


    try {
      tmp.setStatus(Integer.valueOf(mstOwnerForm.getStatus()));
    } catch (NumberFormatException e) {
      tmp.setStatus(1);
    }
    tmp.setUpdatedAt(LocalDateTime.now());
    tmp.setUpdatedMstUserId(0);// userのidがわからないため保留
    MstOwner result = mstOwnerRepository.save(tmp);

    logger.info("--- MstOwnerService.saveUser END ---");
    return result;

  }
}
