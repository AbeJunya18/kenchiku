package com.seproject.buildmanager.service;

import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Service;
import com.seproject.buildmanager.entity.MstCheckGroupe;
import com.seproject.buildmanager.repository.MstCheckGroupeRepositry;


@Service
public class MstCheckGroupeService {

  private static final Logger logger = LoggerFactory.getLogger(SpringBootApplication.class);

  @Autowired
  private MstCheckGroupeRepositry mstCheckGroupeRepositry;

  public List<MstCheckGroupe> getAllGroupes() {

    logger.info("--- MstCheckGroupeService.getAllGroupes START ---");

    List<MstCheckGroupe> groupes = mstCheckGroupeRepositry.findAll();

    logger.info("--- MstUserService.getAllGroupes END ---");

    return groupes;
  }

  //
  // public Optional<MstCheckGroupe> getGroupeById(Integer id) {
  // return mstCheckGroupeRepositry.findById(id);
  // }
  //
  // public void saveGroupe(MstCheckGroupe groupe) {
  // mstCheckGroupeRepositry.save(groupe);
  // }
  //
  // public void deleteGroupe(Integer id) {
  // mstCheckGroupeRepositry.deleteById(id);
  // }
}
