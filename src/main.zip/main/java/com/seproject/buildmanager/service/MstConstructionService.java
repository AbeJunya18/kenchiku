package com.seproject.buildmanager.service;

import org.springframework.stereotype.Service;
import com.seproject.buildmanager.form.MstConstructionForm;

@Service
public class MstConstructionService {
  public MstConstructionForm constructionForm() {
    MstConstructionForm constructionForm = new MstConstructionForm();

    return constructionForm;
  }

}
