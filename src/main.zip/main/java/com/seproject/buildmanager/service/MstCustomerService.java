package com.seproject.buildmanager.service;

import java.time.LocalDateTime;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import com.seproject.buildmanager.entity.MstCustomer;
import com.seproject.buildmanager.form.MstCustomerForm;
import com.seproject.buildmanager.repository.MstCustomerRepository;


@Service
public class MstCustomerService {

  private static final Logger logger = LoggerFactory.getLogger(SpringBootApplication.class);

  @Autowired
  private MstCustomerRepository mstCustomerRepository;

  @Autowired
  private PasswordEncoder passwordEncoder;


  public List<MstCustomer> getAllCustomers() {

    logger.info("--- MstCustomerService.getAllCustomers START ---");

    List<MstCustomer> customer = mstCustomerRepository.findAll();

    logger.info("--- MstCustomerService.getAllCustomer END ---");

    return customer;

  }

  public MstCustomerForm showCustomerForm() {

    logger.info("--- MstCustomerService.showCustomerForm START ---");

    MstCustomerForm tmp = new MstCustomerForm();

    logger.info("--- MstCustomerService.showCustomerForm END ---");

    return tmp;

  }

  public MstCustomer saveCustomer(MstCustomerForm mstCustomerForm) {

    logger.info("--- MstCustomerService.saveCustomer START ---");

    MstCustomer tmp = new MstCustomer();
    tmp.setCorpName(mstCustomerForm.getCorpName());
    tmp.setCorpKana(mstCustomerForm.getCorpKana());
    tmp.setDepartment(mstCustomerForm.getDepartment());
    tmp.setLName(mstCustomerForm.getLName());
    tmp.setFName(mstCustomerForm.getFName());
    tmp.setLNameKana(mstCustomerForm.getLNameKana());
    tmp.setFNameKana(mstCustomerForm.getFNameKana());
    tmp.setZip(mstCustomerForm.getZip());
    tmp.setAddress1(mstCustomerForm.getAddress1());
    tmp.setAddress2(mstCustomerForm.getAddress2());
    tmp.setTel(mstCustomerForm.getTel());
    tmp.setMobile(mstCustomerForm.getMobile());
    tmp.setMail(mstCustomerForm.getMail());
    try {
      tmp.setStatus(Integer.valueOf(mstCustomerForm.getStatus()));
    } catch (NumberFormatException e) {
      tmp.setStatus(1);
    }
    tmp.setRegistDate(LocalDateTime.now());
    tmp.setUpdateDate(LocalDateTime.now());
    // TODO:登録ユーザは未対応
    MstCustomer result = mstCustomerRepository.save(tmp);

    logger.info("--- MstCustomerService.saveCustomer END ---");
    return result;

  }

  public MstCustomer getCustomerById(Integer id) {
    return mstCustomerRepository.findById(id).orElse(new MstCustomer());
  }


}
