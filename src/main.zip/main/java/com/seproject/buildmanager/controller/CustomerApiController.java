package com.seproject.buildmanager.controller;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.seproject.buildmanager.repository.MstCustomerRepository;

@RestController
@RequestMapping("/api/customer")
public class CustomerApiController {

  @Autowired
  private MstCustomerRepository mstCustomerRepository;

  @PutMapping("/toggleStatus")
  public ResponseEntity<String> toggleCustomerStatus(@RequestBody Map<String, Integer> request) {
    Integer custId = request.get("custId");
    try {
      mstCustomerRepository.toggleStatus(custId);
      return ResponseEntity.ok("Status toggled for customer with ID " + custId);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error toggling status");
    }
  }
}
