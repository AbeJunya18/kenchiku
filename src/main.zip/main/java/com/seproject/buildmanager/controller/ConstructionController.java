package com.seproject.buildmanager.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.security.web.csrf.CsrfToken;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import com.seproject.buildmanager.service.MstConstructionService;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class ConstructionController {
  private static final Logger logger = LoggerFactory.getLogger(SpringBootApplication.class);

  @Autowired
  private MstConstructionService mstConstructionService;

  @GetMapping("/koji_kubun_bunrui") // 工事区分分類管理画面を表示する
  public String viewKojiKubunBunrui(Model model, HttpServletRequest request) {
    logger.info("--- ConstructionController.viewKojiKubunBunrui START ---");

    logger.info("--- ConstructionController.viewKojiKubunBunrui END ---");

    // CSRFトークンをモデルに追加
    CsrfToken csrfToken = (CsrfToken) request.getAttribute(CsrfToken.class.getName());
    model.addAttribute("csrfToken", csrfToken.getToken());
    model.addAttribute("csrfHeaderName", csrfToken.getHeaderName());
    model.addAttribute("ConstructionForm", mstConstructionService.constructionForm());


    return "sakoda_kozi_bunntanngamenn/koji_kubun_bunrui";
  }

}
