package com.seproject.buildmanager.controller;

import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.seproject.buildmanager.common.Constants;
import com.seproject.buildmanager.common.MstCodeEnums;
import com.seproject.buildmanager.config.TransactionTokenCheck;
import com.seproject.buildmanager.entity.MstCustomer;
import com.seproject.buildmanager.form.MstOwnerForm;
import com.seproject.buildmanager.repository.MstOwnerRepository;
import com.seproject.buildmanager.service.MstCodeService;
import com.seproject.buildmanager.service.MstCustomerService;
import com.seproject.buildmanager.service.MstOwnerService;
import jakarta.servlet.http.HttpSession;

@Controller
@RequestMapping("owner")
public class OwnerController {
  private static final Logger logger = LoggerFactory.getLogger(SpringBootApplication.class);

  @Autowired
  private MstOwnerService mstOwnerService;

  @Autowired
  private MstCustomerService mstCustomerService;

  @Autowired
  private MstCodeService mstCodeService;

  @Autowired
  private MstOwnerRepository mstOwnerRepository;

  // Enumから都道府県のcode_kindの値を取得
  private static final int PREFECTURES = MstCodeEnums.PREFECTURES.getValue();

  // 同じく法人・個人のcode_kindの値を取得
  private static final int INDIVIDUAL_CORPORATE = MstCodeEnums.INDIVIDUAL_CORPORATE.getValue();

  @GetMapping("")
  public String getAllOwner(Model model) {// オーナー管理画面

    logger.info("--- OwnerController.getAllOwner START ---");

    model.addAttribute("owner", mstOwnerService.getAllOwner());
    model.addAttribute("statusTrue", Constants.STATUS_TRUE);

    logger.info("--- UserController.getAllUsers END ---");
    return "owner/owner";
  }

  // ---------------------------新規登録---------------------------------
  @GetMapping("register")
  public String registerOwnerForm(HttpSession session, Model model) {// 新規登録画面

    logger.info("--- OwnerController.registerOwnerForm START ---");

    List<MstCustomer> customer = mstCustomerService.getAllCustomers();
    model.addAttribute("customer", customer);

    model.addAttribute("inputCustomer", new MstCustomer());

    String transactionToken = UUID.randomUUID().toString();
    session.setAttribute("transactionToken", transactionToken);
    model.addAttribute("transactionToken", transactionToken);

    // 都道府県のリスト
    model.addAttribute("prefectures", mstCodeService.getCodeByKind(PREFECTURES));
    // 法人か個人か
    model.addAttribute("individual", mstCodeService.getCodeByKind(INDIVIDUAL_CORPORATE));

    model.addAttribute("mstOwner", mstOwnerService.registerOwnerForm());

    logger.info("--- OwnerController.registerOwnerForm END ---");

    return "owner/owner_register";
  }

  @PostMapping("register")
  public String processRegistration(MstOwnerForm mstOwnerForm, Model model) {// 新規登録確認画面

    logger.info("--- OwnerController.processRegistration START ---");

    mstOwnerForm.setClient(mstCustomerService
        .getCustomerById(Integer.parseInt(mstOwnerForm.getClientId())).getCorpName());
    model.addAttribute("mstOwnerForm", mstOwnerForm);


    logger.info("--- OwnerController.processRegistration END ---");
    return "owner/owner_register_confirm";
  }

  @PostMapping("saveRegister")
  @TransactionTokenCheck("saveRegister")
  public String saveOwnerRegister(MstOwnerForm mstOwnerForm) {// DBに登録

    logger.info("--- OwnerController.saveOwner START ---");

    mstOwnerService.saveOwnerRegister(mstOwnerForm);

    logger.info("--- OwnerController.saveOwner END ---");
    return "redirect:/owner/saveRegister";
  }

  @GetMapping("saveRegister")
  public String createCompleteRegister() {// 新規登録完了画面
    return "owner/owner_register_end";
  }

  // ---------------------------------------------------------------------------
  // ---------------------------変更---------------------------------
  @GetMapping("update")
  public String updateOwnerForm(@RequestParam(value = "id") int id, HttpSession session,
      Model model) {
    logger.info("--- OwnerController.updateOwnerForm START ---");

    String transactionToken = UUID.randomUUID().toString();
    session.setAttribute("transactionToken", transactionToken);
    model.addAttribute("transactionToken", transactionToken);

    model.addAttribute("prefectures", mstCodeService.getCodeByKind(PREFECTURES));
    model.addAttribute("individual", mstCodeService.getCodeByKind(INDIVIDUAL_CORPORATE));

    List<MstCustomer> customer = mstCustomerService.getAllCustomers();
    model.addAttribute("customer", customer);
    model.addAttribute("mstOwner", mstOwnerService.getOwnerId(id));

    logger.info("--- OwnerController.updateOwnerForm END ---");

    return "owner/owner_update";
  }

  @PostMapping("update")
  public String processUpdate(MstOwnerForm mstOwnerForm, Model model) {
    logger.info("--- OwnerController.processUpdate START ---");

    model.addAttribute("mstOwnerForm", mstOwnerForm);

    logger.info("--- OwnerController.processUpdate END ---");
    return "owner/owner_update_confirm";
  }

  @PostMapping("saveUpdate")
  @TransactionTokenCheck("saveUpdate")
  public String saveOwnerUpdate(@ModelAttribute("mstOwnerForm") MstOwnerForm mstOwnerForm) {// DBに登録

    logger.info("--- OwnerController.saveOwner START ---");

    mstOwnerService.saveOwnerUpdate(mstOwnerForm);

    logger.info("--- OwnerController.saveOwner END ---");
    return "redirect:/owner/save";
  }

  @GetMapping("saveUpdate")
  public String createCompleteUpdate() {// 変更完了画面
    return "owner/register_end";
  }
}
