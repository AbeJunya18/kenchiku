package com.seproject.buildmanager.controller;

import java.util.List;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.seproject.buildmanager.common.Constants;
import com.seproject.buildmanager.common.MstCodeEnums;
import com.seproject.buildmanager.config.TransactionTokenCheck;
import com.seproject.buildmanager.entity.MstCustomer;
import com.seproject.buildmanager.form.MstCustomerForm;
import com.seproject.buildmanager.form.MstOwnerForm;
import com.seproject.buildmanager.service.MstCodeService;
import com.seproject.buildmanager.service.MstCustomerService;
import jakarta.servlet.http.HttpSession;


@Controller
@RequestMapping("customer")
public class CustomerController {

  private static final Logger logger = LoggerFactory.getLogger(SpringBootApplication.class);

  @Autowired
  private MstCustomerService mstCustomerService;

  @Autowired
  private MstCodeService mstCodeService;

  // Enumから都道府県のcode_kindの値を取得
  private static final int PREFECTURES = MstCodeEnums.PREFECTURES.getValue();

  // 同じく法人・個人のcode_kindの値を取得
  private static final int INDIVIDUAL_CORPORATE = MstCodeEnums.INDIVIDUAL_CORPORATE.getValue();


  @GetMapping("")
  public String getAllCustomer(Model model) {

    logger.info("--- CustomerController.getAllCustomer START ---");

    model.addAttribute("customer", mstCustomerService.getAllCustomers());
    model.addAttribute("statusTrue", Constants.STATUS_TRUE);

    logger.info("--- CustomerController.getAllcustomer END ---");
    return "customer/kokyaku";
  }

  @GetMapping("register")
  public String showCustomerForm(HttpSession session, Model model) {

    logger.info("--- CustomerController.showCustomerForm START ---");

    String transactionToken = UUID.randomUUID().toString();
    session.setAttribute("transactionToken", transactionToken);
    model.addAttribute("transactionToken", transactionToken);

    model.addAttribute("mstCustomer", mstCustomerService.showCustomerForm());

    // 都道府県のリスト
    model.addAttribute("prefectures", mstCodeService.getCodeByKind(PREFECTURES));
    // 法人か個人か
    model.addAttribute("individual", mstCodeService.getCodeByKind(INDIVIDUAL_CORPORATE));

    logger.info("--- CustomerController.showCustomerForm END ---");

    return "customer/kokyaku_register";
  }


  @PostMapping("register")
  public String processRegistration(MstCustomerForm mstCustomerForm, Model model) {

    logger.info("--- CustomerController.processRegistration START ---");
    model.addAttribute("mstCustomer", new MstCustomer());
    model.addAttribute("mstCustomerForm", mstCustomerForm);



    logger.info("--- CustomerController.processRegistration END ---");
    return "customer/kokyaku_register_confirm";
  }

  @PostMapping("save")
  @TransactionTokenCheck("save")
  public String saveCustomer(@ModelAttribute("mstCustomerForm") MstCustomerForm mstCustomerForm) {

    logger.info("--- CustomerController.saveCustomer START ---");

    mstCustomerService.saveCustomer(mstCustomerForm);

    logger.info("--- CustomerController.saveCustomer END ---");
    return "redirect:/customer/save";
  }

  @GetMapping("save")
  public String createComplete() {
    return "customer/kokyaku_register_end";
  }


  @GetMapping("update")
  public String updateCustomerForm(@RequestParam(value = "id") int id, HttpSession session,
      Model model) {
    logger.info("--- CustomerController.updateCustomerForm START ---");

    String transactionToken = UUID.randomUUID().toString();
    session.setAttribute("transactionToken", transactionToken);
    model.addAttribute("transactionToken", transactionToken);

    model.addAttribute("prefectures", mstCodeService.getCodeByKind(PREFECTURES));
    model.addAttribute("individual", mstCodeService.getCodeByKind(INDIVIDUAL_CORPORATE));

    List<MstCustomer> customer = mstCustomerService.getAllCustomers();
    model.addAttribute("customer", customer);
    model.addAttribute("mstCustomer", mstCustomerService.getCustomerById(id));

    logger.info("--- CustomerController.updateCustomerForm END ---");

    return "customer/kokyaku_update";
  }

  @PostMapping("update")
  public String processUpdate(MstOwnerForm mstCustomerForm, Model model) {
    logger.info("--- CustomerController.processUpdate START ---");

    model.addAttribute("mstCustomerForm", mstCustomerForm);

    logger.info("--- CustomerController.processUpdate END ---");
    return "customer/kokyaku_update_confirm";
  }

  @PostMapping("saveUpdate")
  @TransactionTokenCheck("saveUpdate")
  public String saveCustomerUpdate(
      @ModelAttribute("mstCustomerForm") MstCustomerForm mstCustomerForm) {// DBに登録

    logger.info("--- CustomerController.saveCustomer START ---");

    mstCustomerService.saveCustomer(mstCustomerForm);

    logger.info("--- CustomerController.saveCustomer END ---");
    return "redirect:/customer/save";
  }

  @GetMapping("saveUpdate")
  public String createCompleteUpdate() {// 変更完了画面
    return "Customer/kokyaku_register_end";
  }
}
