package com.seproject.buildmanager.controller;

import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.seproject.buildmanager.repository.MstUserRepository;

@RestController
@RequestMapping("/api/user")
public class UserApiController {

  @Autowired
  private MstUserRepository mstUserRepository;

  @PutMapping("/toggleStatus")
  public ResponseEntity<String> toggleUserStatus(@RequestBody Map<String, Integer> request) {
    Integer userId = request.get("userId");
    try {
      mstUserRepository.toggleStatus(userId);
      return ResponseEntity.ok("Status toggled for user with ID " + userId);
    } catch (Exception e) {
      return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Error toggling status");
    }
  }
}
