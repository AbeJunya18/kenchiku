package com.seproject.buildmanager.controller;



import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import com.seproject.buildmanager.common.Constants;
import com.seproject.buildmanager.service.MstCheckGroupeService;

@Controller
@RequestMapping("checkchange")
public class Check_ChangeController {

  private static final Logger logger = LoggerFactory.getLogger(SpringBootApplication.class);
  private MstCheckGroupeService mstCheckGroupeService; // サービスのインスタンス


  // コンストラクタインジェクションを使用してMstCheckGroupeServiceの依存性を注入
  public Check_ChangeController(MstCheckGroupeService mstCheckGroupeService) {
    this.mstCheckGroupeService = mstCheckGroupeService;
  }

  @GetMapping("")
  public String getCheck_group(Model model) {

    logger.info("--- Check_ChangeController.getAllGroupes START ---");

    model.addAttribute("checkchange", mstCheckGroupeService.getAllGroupes());
    model.addAttribute("statusTrue", Constants.STATUS_TRUE);
    // DBデータ全表示呼び出しメソッドをオブジェクトへ追加
    logger.info("--- Check_ChangeController.getAllGroupes END ---");
    return "check/check_group_register";// 同じ画面へ返す
  }

  // @PostMapping("save") // フォームに入力されたグループ名を受け取ってsarviceメソッドを実行して、同じ画面へ遷移する
  // public String saveCheck_group(@RequestParam("check_group_save") MstCheckGroupe check_groupe) {
  // MstCheckGroupe groupe = new MstCheckGroupe();
  // mstCheckGroupeService.saveGroupe(groupe);
  // return "check/check_group_register";
  // }
  //
  // @PostMapping("check_group_update") // フォームに入力されたグループ名を受け取ってsarviceメソッドを実行して、同じ画面へ遷移する
  // public String updateCheck_group(@RequestParam("check_group_update") String check_group_update)
  // {
  // MstCheckGroupe groupe = new MstCheckGroupe();
  // groupe.setCheck_groupe_name(check_group_update);
  // return "check/check_group_register";
  // }


}
